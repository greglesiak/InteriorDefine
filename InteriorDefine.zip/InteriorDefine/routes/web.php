<?php

//use App\Product;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/foo', function () {
    return 'Hello World';
});

Route::get('/', function () {
    return view('interiordefine');
});

Route::get('/products', function(){
	$products = \App\Products::all();

	return view('interiordefine', ['products' => $products]);
});


//Route::resource('products', 'ProductController');