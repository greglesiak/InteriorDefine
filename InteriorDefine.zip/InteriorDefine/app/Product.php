<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    
 public function options()
    {
      return $this->hasMany(Options::class);
    }

    protected $fillable = ['sku', 'price', 'product_type', 'product_line'];
}
