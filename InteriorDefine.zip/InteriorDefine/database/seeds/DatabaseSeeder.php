<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            'sku' => random_int(100000, 199999),
            'price' => 1000,
            'product_line' => str_random(10),
            'product_type' => 'couch',
        ]);
    }
}
